---
name: fpa-month-end-close
description: Management month-end close for FP&A — data completeness checks, entity-to-group tie-outs, cut-off and accrual sanity checks, data-quality gates and a close sign-off log before any management pack is built. Use WHENEVER the user mentions month-end close, closing the month, period close, "is the data ready", close checklist, tie-out, reconciliation of entity P&L files to the consolidated view, late or missing entity submissions, accrual review, or starts a monthly management reporting cycle. This is management reporting, not IFRS/GAAP statutory reporting.
---

# FP&A Month-End Close (Management View)

## Purpose
Make sure the numbers are complete, consistent and explainable BEFORE they reach management. The output of this skill is a **Close Readiness Report** with a clear status: READY, READY WITH EXCEPTIONS, or NOT READY.

## When the close starts
1. Identify the reporting month (e.g. 2026-09) and the YTD range (2026-01 to 2026-09).
2. Identify every reporting entity from the group master (entity list, source file per entity).
3. Identify the scenarios required: Actual, Budget, Prior Year and, if available, the latest Forecast.

## Step 1 — Completeness gate
For every entity and scenario check:
- The source file exists in the agreed folder (e.g. Microsoft 365 / SharePoint "01_Actuals/2026-09").
- The reporting month column exists and is not empty.
- Every GL account in the chart of accounts is present; list missing, new or unmapped accounts.
- Driver data (units, hours, subscriptions, headcount) exists for the month.
If anything is missing, never invent it. Mark it as a data gap and state which report lines are affected.

## Step 2 — Integrity checks
- Rebuild every subtotal from detail rows only (Row Type = Detail). Compare to stored subtotals; tolerance ±1 USD.
- Sign convention: income positive, cost negative. Flag any line with an unexpected sign.
- Consolidated = sum of entities (plus eliminations if the group master requires them). Tie the result to the expected consolidated totals if a control sheet exists.
- YTD = sum of months. Check against any Variance_Check / control sheet.
- Tax sanity: effective tax rate vs the stated policy (e.g. 22% of profit before tax).

## Step 3 — Management-level cut-off and accrual review
Flag, do not correct, the following patterns (threshold: > 10% vs 3-month average AND > USD 25k, unless the user defines other thresholds):
- Fixed-cost lines (rent, depreciation, insurance) that move unexpectedly.
- Revenue spikes in the last month of a quarter.
- Cost lines that are zero in the month but recurring in prior months (possible missing accrual).
- Double-counting risk: a cost line at ~2x its run-rate (possible duplicate accrual).
- One-offs mentioned by the user (bonus true-up, legal settlement, reclassifications) — confirm they are visible in the data.

## Step 4 — Close Readiness Report (output format)
| Section | Content |
|---|---|
| Status | READY / READY WITH EXCEPTIONS / NOT READY |
| Scope | Month, entities, scenarios, source files and timestamps |
| Checks passed | List with result |
| Exceptions | Entity, account, amount, issue, impact on pack, owner, due |
| Adjustments noted | Management adjustments supplied by the user (never self-created) |
| Sign-off | Prepared by, reviewed by, date |

## Rules
- Management reporting only: focus on decision-useful accuracy, not statutory disclosure.
- Never overwrite source data. Work on a copy and document every transformation.
- Quantify every exception in USD thousands and state which KPI or slide it affects.
- If status is NOT READY, stop and ask whether to continue with flagged, provisional numbers.
