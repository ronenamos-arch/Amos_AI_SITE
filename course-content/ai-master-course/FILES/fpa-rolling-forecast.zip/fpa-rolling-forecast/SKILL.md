---
name: fpa-rolling-forecast
description: Rolling forecast and full-year outlook for FP&A — latest estimate (LE), YTD actuals plus remaining-months forecast, driver-based and run-rate methods, seasonality, scenarios (base/upside/downside), risks and opportunities register, forecast accuracy tracking and gap-to-budget analysis. Use WHENEVER the user mentions forecast, reforecast, latest estimate, LE, full-year outlook, landing, run-rate, "where will we end the year", 3+9 / 6+6 / 9+3, rolling 12 months, scenarios, risks and opportunities, or gap to target.
---

# Rolling Forecast and Full-Year Outlook

## 1. Structure
- **LE (latest estimate) = YTD Actual + Forecast for remaining months.** Label it e.g. "9+3 FY2026".
- Keep the same account structure and entities as actuals and budget.
- Always show FY Budget, FY LE, Gap (LE − BUD) and PY full year if available.

## 2. Method selection (state the method on the slide)
| Situation | Method |
|---|---|
| Drivers available (units, hours, subscriptions, FTE) | Driver-based: volume × rate per entity |
| Stable business, no drivers | Run-rate: average of last 3 months, adjusted for seasonality from PY or budget phasing |
| Remaining budget considered achievable | Budget phasing × YTD performance ratio |
| Known events (price increase, new contract, hiring plan) | Base method + explicit adjustments listed one by one |

Seasonality: if budget or PY monthly phasing exists, use it; otherwise flag that the run-rate ignores seasonality.

## 3. Driver-based build (default)
- Revenue = volume driver × price/rate (units × price, billable hours × rate, subscriptions × ARPU).
- Cost of sales = variable cost per unit × volume + fixed overhead.
- Opex = headcount × cost per FTE + non-people costs (run-rate + known items).
- D&A = fixed schedule unless capex changes. Tax = policy rate on positive profit before tax.

## 4. Scenarios
Base (most likely), Upside and Downside with no more than 3–4 named assumptions each. Show FY Revenue and FY EBITDA for each scenario in one table. Never average scenarios.

## 5. Risks and opportunities register
| Item | Entity | Type (R/O) | FY EBITDA impact k | Probability | Owner | Included in LE? |
Items with probability ≥ 50% are included in the base LE; others are shown below the line.

## 6. Forecast accuracy
Track each month: forecast for the month (made last cycle) vs actual; accuracy % = 1 − |ACT − FC| / |ACT|. Comment when accuracy < 95% on revenue or < 90% on EBITDA.

## 7. Rules
- Never present an assumption as a fact. Every forecast number must trace to a method and an input.
- If remaining-month budget or drivers are missing, say so and label the output "illustrative".
- Quantify the gap to budget and list the actions needed to close it.
- Keep forecast versions: the 2026-09 LE never overwrites the 2026-08 LE.
