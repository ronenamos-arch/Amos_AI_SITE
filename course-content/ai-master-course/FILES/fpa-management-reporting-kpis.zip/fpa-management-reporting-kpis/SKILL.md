---
name: fpa-management-reporting-kpis
description: Build the core management reports, executive summaries and KPI scorecards for a monthly management pack — consolidated and entity P&L summaries (Month, YTD, Actual vs Budget vs Prior Year), margin analysis, operational KPIs (revenue per FTE, subscriptions, billable hours, units) and RAG status. Use WHENEVER the user asks for a management report, monthly summary, executive summary, KPI dashboard or scorecard, P&L summary, flash report, CFO or board summary, or "how did we do this month". Management reporting, not IFRS/GAAP financial statements.
---

# Management Reports, Summaries and KPIs

## Standard report set
1. **Executive summary** — 3 to 5 headline messages, each with a number and a "so what".
2. **Group P&L summary** — Net revenue, Gross profit, GM%, Operating expenses by function, EBITDA, EBITDA %, EBIT, Net income.
3. **Entity performance** — same lines per entity, plus share of group.
4. **KPI scorecard** — financial and operational KPIs with target, actual, prior year and RAG.
5. **Trend view** — last 9–12 months, Actual vs Budget.

## Standard column layout
For Month and for YTD: `ACT | BUD | Var | Var % | PY | Var | Var %`
- Var = ACT − BUD (and ACT − PY). With costs stored as negatives, a positive variance is always favourable.
- Var % = Var / |BUD| (or |PY|). Show "n/m" when the base is zero or the sign flips.
- Units: USD thousands, one decimal for %, no decimals for amounts. State units on every table.

## KPI library (definitions must be stated in the pack appendix)
| KPI | Formula | Default RAG |
|---|---|---|
| Revenue growth vs PY | (ACT − PY) / PY | G ≥ budget growth; A within 1pp; R below |
| Gross margin % | Gross profit / Net revenue | G ≥ BUD; A −0.5pp; R worse |
| EBITDA margin % | EBITDA / Net revenue | G ≥ BUD; A −1pp; R worse |
| Opex % of revenue | Total opex excl. D&A / Net revenue | G ≤ BUD |
| Revenue per FTE | Net revenue / average FTE | G ≥ BUD |
| Headcount vs budget | FTE ACT − FTE BUD | G ≤ 0 |
| Subscriptions | Active subscriptions at month end | G ≥ BUD |
| Billable hours per FTE | Billable hours / FTE | G ≥ BUD |
| Conversion to net income | Net income / EBITDA | informational |
Only compute KPIs the data supports. If a driver is missing, show "data not available" and say what is needed.

## Executive summary writing rules
- Lead with the answer: "September EBITDA of 1,984k was 1.0% above budget and 5.6% above last year."
- Every message = fact + driver + implication/action.
- Separate MONTH from YTD — never mix them in one sentence without labels.
- Maximum 60 words per message. No jargon, no accounting-standard language.
- Flag data gaps and provisional numbers explicitly.

## Quality checklist
- Consolidated totals equal the sum of entities.
- Month figures sum to YTD.
- Every % in text matches the tables.
- Favourable/unfavourable wording matches the sign.
- Period, currency and scenario labels appear on every page.
