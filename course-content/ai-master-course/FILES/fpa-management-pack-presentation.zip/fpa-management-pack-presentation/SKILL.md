---
name: fpa-management-pack-presentation
description: Turn monthly FP&A analysis into a management pack PowerPoint — storyline, standard slide order, executive summary slide, P&L tables, KPI tiles, trend charts, EBITDA bridges, entity pages, outlook, risks and decisions required — with consistent formatting and a numbers QA. Use WHENEVER the user asks for a monthly management pack, management presentation, board or CFO deck, reporting pack slides, or "turn this report into PPT". Combine with the pptx skill for file creation.
---

# Monthly Management Pack Presentation

## Storyline (answer first, detail later)
1. Title — group name, "Monthly Management Pack", month, currency/units, date, prepared by.
2. Executive summary — 4 KPI tiles (Month Revenue, Month EBITDA, YTD Revenue, YTD EBITDA with var vs BUD and PY) + 3–5 key messages.
3. Group P&L summary — Month and YTD tables (ACT | BUD | Var | Var % | PY | Var %).
4. Trends — monthly revenue ACT vs BUD and EBITDA margin.
5. EBITDA bridge — Budget → Actual YTD (and Month when material).
6. Entity performance — one overview slide; deep-dive slides only for entities off plan.
7. Variance drivers — top 5–8 with commentary, owner and action.
8. KPI scorecard — financial and operational KPIs with RAG.
9. Outlook — FY latest estimate vs budget, scenarios.
10. Risks, opportunities and decisions required.
11. Appendix — detailed P&L, KPI definitions, data-quality notes.

## Slide standards
- Action titles: the title states the conclusion ("YTD EBITDA 0.8% below budget; Company A materials the main drag"), not just "EBITDA".
- One message per slide. Max ~40 words of body text on chart slides.
- Units in every chart/table caption: "USD k". Periods labelled "Sep-26", "YTD Sep-26".
- Colours: favourable = green, unfavourable = red, budget = grey, actual = brand primary. Never rely on colour alone — show signs and F/U.
- Native, editable PowerPoint charts and tables (not pictures).
- Footer: source (files / connector folder), data status (final / provisional), page number.

## Numbers QA before delivery
- Every number on slides ties to the analysis tables (check all headline figures).
- Month and YTD labels correct; variance signs match F/U wording.
- Totals = sum of entities; bridge bars sum to actual.
- No placeholder text, no overflow, consistent decimals.
- Data gaps or provisional figures are disclosed on the executive summary slide.

## Speaker notes
Add 3–5 talking points per slide for the presenter (CFO / Head of FP&A), including the question management is likely to ask and the prepared answer.
