---
name: fpa-variance-analysis
description: FP&A variance analysis and commentary — Actual vs Budget, Actual vs Prior Year and Actual vs Forecast, by line, function and entity; materiality thresholds; price/volume/mix and driver-based decomposition; EBITDA bridges (waterfalls); root-cause commentary with owners and actions. Use WHENEVER the user mentions variance, BvA, budget vs actual, vs last year, over/under budget, favourable/unfavourable, bridge or waterfall, explaining results, commentary, flux analysis, or "why did EBITDA miss".
---

# Variance Analysis and Commentary

## 1. Set the comparison frame
- Periods: Month and YTD (and QTD at quarter end).
- Comparisons: ACT vs BUD (primary), ACT vs PY (growth), ACT vs latest FC (forecast accuracy).
- Level: Group → Entity → Function → GL line. Drill down only where material.

## 2. Materiality (defaults, user may override)
Comment on a variance if it is **> USD 50k AND > 5%** at line level, or **> USD 100k** at any level, or if management has flagged the topic. Always comment on Revenue, Gross profit, EBITDA and Net income regardless of size.

## 3. Sign and wording
Costs are stored as negatives, so Var = ACT − BUD is favourable when positive for every line. Use "favourable (F)" / "unfavourable (U)". Never write "costs increased favourably".

## 4. Decomposition techniques
- **Price / Volume / Mix (revenue):** Volume = (ACT units − BUD units) × BUD price; Price = (ACT price − BUD price) × ACT units; Mix = residual across products/entities.
- **Rate / Volume (costs):** Rate = (ACT cost per unit − BUD cost per unit) × ACT units; Volume = (ACT units − BUD units) × BUD cost per unit.
- **Headcount:** FTE variance × budget cost per FTE, and cost-per-FTE variance × actual FTE.
- **Margin:** gross margin % change vs the revenue variance — separate "we sold more" from "we earned less per sale".
- **Timing vs permanent:** classify each variance as Timing (reverses within the year), Permanent, or One-off.

## 5. EBITDA bridge
Budget EBITDA → Revenue → Cost of sales → Sales & marketing → G&A → R&D → Actual EBITDA. D&A is excluded from an EBITDA bridge. The bars must sum exactly to the actual; show a rounding item if needed. Build the same bridge for PY → ACT when growth is discussed.

## 6. Commentary standard (per material variance)
`[Line/Entity] [amount]k [F/U] ([%]) vs budget, driven by [root cause with driver numbers]. [Timing/Permanent/One-off]. Action: [owner, what, when].`

Example: "Company A direct materials 294k U YTD with product revenue 269k below budget: material cost per unit is above plan while volume is lower. Permanent unless supplier pricing is renegotiated. Action: Procurement to present options by 15 Oct."

## 7. Rules
- Never invent root causes. If the data does not explain a variance, write "driver not identifiable from data — to be confirmed by [owner]" and list the question to ask.
- Use the context supplied by the user (events of the month) before inferring.
- Rank variances by absolute EBITDA impact; show the top 5–8 in the main pack, the rest in the appendix.
- Reconcile: sum of explained variances + unexplained = total variance.
